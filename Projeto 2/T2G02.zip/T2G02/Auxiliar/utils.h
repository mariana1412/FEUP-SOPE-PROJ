#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>      
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <pthread.h>

void start_time();
void regOper();

#endif /*UTILS_H*/